#include <cstdlib>
#include "Windows.h"
#include "CStream.h"

CStreamSQ::CStreamSQ(void) : m_iFront(0), m_iRear(0), m_iSize(1000), m_pBuffer((char*)malloc(sizeof(char) * 1000))
{
	Initial(1000 );
}

CStreamSQ::CStreamSQ(int iBufferSize) : m_iFront(0), m_iRear(0), m_iSize(iBufferSize), m_pBuffer((char*)malloc(sizeof(char) * (iBufferSize)))
{
	Initial(iBufferSize);
}

void CStreamSQ::Initial(int iBufferSize)
{
	memset(m_pBuffer, 0, iBufferSize);
}

int CStreamSQ::GetBufferSize(void)
{
	return m_iSize;
}

int CStreamSQ::GetUseSize(void)
{
	if (m_iFront > m_iRear)
	{
		return m_iSize - m_iFront + m_iRear;
	}
	else
	{
		return m_iRear - m_iFront;
	}
}

int CStreamSQ::GetFreeSize(void)
{
	if (m_iFront > m_iRear)
	{
		return m_iFront - m_iRear;
	}
	else
	{
		return m_iSize - m_iRear + m_iFront;
	}
}

int CStreamSQ::SecureEnqueueSize(void)
{
	return m_iSize - m_iRear;
}

int CStreamSQ::SecureDequeueSize(void)
{
	return m_iSize - m_iFront;
}

int CStreamSQ::Enqueue(char * chpData, int iSize)
{
	int iFree = GetFreeSize();	// front�� rear�� ������ ���� ���⼭ �ذ�
	
	// ���� ������ ������ ũ�⺸�� ���� ���
	if (iFree < iSize)	
	{
		iSize = iFree;
		if (m_iFront > m_iRear)	// front�� rear���� �ڿ� ���� ���
		{
			memcpy(m_pBuffer + m_iFront, chpData, iSize);
			m_iRear += iSize;
		}
		else
		{
			if (iSize < m_iSize - m_iRear)
			{
				memcpy(m_pBuffer + m_iFront, chpData, iSize);
				m_iRear += iSize;
			}
			else
			{
				memcpy(m_pBuffer + m_iFront, chpData, m_iSize - m_iRear);
				memcpy(m_pBuffer, chpData + (m_iSize - m_iRear), iSize - (m_iSize - m_iRear));
				m_iRear = (m_iSize - m_iRear);
			}
		}
		return iSize;
	}


	// ���� ������ �˳��� ���
	if (m_iFront > m_iRear)	// front�� rear���� �ڿ� ���� ���
	{
		memcpy(m_pBuffer + m_iRear, chpData, iSize);	// �����Ͱ� ©�� ���� �����Ƿ� ũ�� �״�� �־��ش�
		m_iRear += iSize;	
	}
	else
	{
		if (iSize < m_iSize - m_iRear)	// ������ ũ�Ⱑ �߸��� �ʴ� ���
		{
			memcpy(m_pBuffer + m_iRear, chpData, iSize);
			m_iRear += iSize;
		}
		else
		{
			memcpy(m_pBuffer + m_iRear, chpData, m_iSize - m_iRear);
			memcpy(m_pBuffer, chpData + (m_iSize - m_iRear), iSize - (m_iSize - m_iRear));
			m_iRear = iSize - (m_iSize - m_iRear);
		}
	}

	return iSize;
}

int CStreamSQ::Dequeue(char * chpDest, int iSize)
{
	int iUse = GetUseSize();
	if (iUse == 0) return 0;

	if (iUse < iSize)
	{
		int iFree = GetFreeSize();
		iSize = iFree;
		if (m_iRear > m_iFront)		// rear�� front���� �ڿ� ���� ���
		{
			memcpy(chpDest, m_pBuffer + m_iFront, m_iRear - m_iFront);
			m_iFront += m_iRear - m_iFront;
		}
		else
		{
			if (iSize < m_iSize - m_iFront)	// ������ ũ�Ⱑ �߸��� �ʴ� ���
			{
				memcpy(chpDest, m_pBuffer + m_iFront, m_iSize - m_iFront);
				m_iFront += m_iSize - m_iFront;
			}
			else
			{
				memcpy(chpDest, m_pBuffer + m_iFront, m_iSize - m_iFront);
				memcpy(chpDest + (m_iSize - m_iFront), m_pBuffer, m_iRear);
				m_iFront = m_iRear;
			}
		}
		return iSize;
	}

	if (m_iRear > m_iFront)		// rear�� front���� �ڿ� ���� ���
	{
		memcpy(chpDest, m_pBuffer + m_iFront, iSize);
		m_iFront += iSize;
	}
	else
	{
		if (iSize < m_iSize - m_iFront)	// ������ ũ�Ⱑ �߸��� �ʴ� ���
		{
			memcpy(chpDest, m_pBuffer + m_iFront, iSize);
			m_iFront += iSize;
		}
		else
		{
			memcpy(chpDest, m_pBuffer + m_iFront, m_iSize - m_iFront);
			memcpy(chpDest + (m_iSize - m_iFront), m_pBuffer, iSize - (m_iSize - m_iFront));
			m_iFront = iSize - (m_iSize - m_iFront);
		}
	}
	return iSize;
}

int CStreamSQ::Peek(char * chpDest, int iSize)
{
	int iUse = GetUseSize();
	if (iUse == 0) return 0;

	if (iUse < iSize)
	{
		int iFree = GetFreeSize();
		iSize = iFree;
		if (m_iRear > m_iFront)	
		{
			memcpy(chpDest, m_pBuffer + m_iFront, m_iRear - m_iFront);
		}
		else
		{
			if (iSize < m_iSize - m_iFront)
			{
				memcpy(chpDest, m_pBuffer + m_iFront, m_iSize - m_iFront);
			}
			else
			{
				memcpy(chpDest, m_pBuffer + m_iFront, m_iSize - m_iFront);
				memcpy(chpDest + (m_iSize - m_iFront), m_pBuffer, m_iRear);
			}
		}
		return iSize;
	}

	if (m_iRear > m_iFront)
	{
		memcpy(chpDest, m_pBuffer + m_iFront, iSize);
	}
	else
	{
		if (iSize < m_iSize - m_iFront)	
		{
			memcpy(chpDest, m_pBuffer + m_iFront, iSize);
		}
		else
		{
			memcpy(chpDest, m_pBuffer + m_iFront, m_iSize - m_iFront);
			memcpy(chpDest + (m_iSize - m_iFront), m_pBuffer, iSize - (m_iSize - m_iFront));
		}
	}
	return iSize;
}

void CStreamSQ::RemoveData(int iSize)
{
	int iUse = GetUseSize();
	if (iUse == 0) return;

	if (iUse < iSize)
	{
		int iFree = GetFreeSize();
		if (m_iRear > m_iFront)
		{
			m_iFront += m_iRear - m_iFront;
		}
		else
		{
			if (iSize < m_iSize - m_iFront)
			{
				m_iFront += m_iSize - m_iFront;
			}
			else
			{
				m_iFront = m_iRear;
			}
		}
		return;
	}

	if (m_iRear > m_iFront)	
	{
		m_iFront += iSize;
	}
	else
	{
		if (iSize < m_iSize - m_iFront)
		{
			m_iFront += iSize;
		}
		else
		{
			m_iFront = iSize - (m_iSize - m_iFront);
		}
	}
	return;
}

int CStreamSQ::MoveWritePos(int iSize)
{
	int iFree = GetFreeSize();

	if (iFree < iSize)
	{
		iSize = iFree;
		if (m_iFront > m_iRear)
		{
			m_iRear += iSize;
		}
		else
		{
			if (iSize < m_iSize - m_iRear)
			{
				m_iRear += iSize;
			}
			else
			{
				m_iRear = (m_iSize - m_iRear);
			}
		}
		return iSize;
	}


	if (m_iFront > m_iRear)	
	{
		m_iRear += iSize;
	}
	else
	{
		if (iSize < m_iSize - m_iRear)
		{
			m_iRear += iSize;
		}
		else
		{
			m_iRear = iSize - (m_iSize - m_iRear);
		}
	}
	return iSize;
}

void CStreamSQ::ClearBuffer(void)
{
	m_iFront = 0;
	m_iRear = 0;
	memset(m_pBuffer, 0, m_iSize);
}

char * CStreamSQ::GetBufferPtr(void)
{
	return m_pBuffer;
}

char * CStreamSQ::GetReadBufferPtr(void)
{
	return m_pBuffer + m_iFront;
}

char * CStreamSQ::GetWriteBufferPtr(void)
{
	return m_pBuffer + m_iRear;
}
